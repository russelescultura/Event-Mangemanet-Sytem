﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using MySql.Data.MySqlClient;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp6
{
    public partial class Update : Form
    {
        private MySqlConnection connection;
        private string eventId;

        public Update()
        {
            InitializeComponent();

           
            string connectionString = "server=localhost;database=eventmanagementdb;user=root;password='';";
            connection = new MySqlConnection(connectionString);

           
            LoadStatusOptions();
        }

        private void LoadStatusOptions()
        {
            try
            {
              
                connection.Open();

                
                string query = "SELECT StatusName FROM Status";

                
                MySqlCommand command = new MySqlCommand(query, connection);

            
                using (MySqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        comboBoxStatus2.Items.Add(reader["StatusName"].ToString());
                    }
                }
            }
            catch (MySqlException ex)
            {
              
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
               
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }
        }




        private void label13_Click(object sender, EventArgs e)
        {

        }

        private void comboBoxStatus2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        internal void PopulateData(DataGridViewRow selectedRow)
        {
            try
            {
               
                eventId = selectedRow.Cells["EventID"].Value.ToString();

                txtEventType2.Text = selectedRow.Cells["EventType"].Value.ToString();
                txtEventName2.Text = selectedRow.Cells["EventName"].Value.ToString();
                dateTimePicker12.Value = Convert.ToDateTime(selectedRow.Cells["EventDateStart"].Value);
                dateTimePicker22.Value = Convert.ToDateTime(selectedRow.Cells["EventDateEnd"].Value);
                dateTimePicker32.Value = dateTimePicker32.Value.Date + (TimeSpan)selectedRow.Cells["TimeStart"].Value;
                dateTimePicker42.Value = dateTimePicker42.Value.Date + (TimeSpan)selectedRow.Cells["TimeEnd"].Value;
                txtCostumerName2.Text = selectedRow.Cells["CustomerName"].Value.ToString(); 
                txtNumGuest2.Text = selectedRow.Cells["NumGuest"].Value.ToString();
                txtAddress2.Text = selectedRow.Cells["Address"].Value.ToString();
                txtContact2.Text = selectedRow.Cells["Contact"].Value.ToString();
                richTxtBoxPreferenances2.Text = selectedRow.Cells["Preferences"].Value.ToString(); 
                comboBoxStatus2.SelectedItem = selectedRow.Cells["Status"].Value.ToString();
                radioMale2.Checked = selectedRow.Cells["Gender"].Value.ToString() == "Male";
                radioFemale2.Checked = selectedRow.Cells["Gender"].Value.ToString() == "Female";
            }
            catch (ArgumentException ex)
            {
                MessageBox.Show($"Error: {ex.Message}\nCheck the column names in the DataGridView and make sure they match the ones used in the code.", "Column Name Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An unexpected error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnUpdate2_Click(object sender, EventArgs e)
        {
            try
            {
               
                connection.Open();

                
                string eventType = txtEventType2.Text;
                string eventName = txtEventName2.Text;
                DateTime eventDateStart = dateTimePicker12.Value;
                DateTime eventDateEnd = dateTimePicker22.Value;
                TimeSpan timeStart = dateTimePicker32.Value.TimeOfDay;
                TimeSpan timeEnd = dateTimePicker42.Value.TimeOfDay;
                string customerName = txtCostumerName2.Text;
                int numGuest = int.Parse(txtNumGuest2.Text);
                string address = txtAddress2.Text;
                string contact = txtContact2.Text;
                string preferences = richTxtBoxPreferenances2.Text;
                string status = comboBoxStatus2.SelectedItem.ToString();
                string gender = radioMale2.Checked ? "Male" : "Female";

              
                string query = @"
                    UPDATE Events 
                    SET EventType = @EventType,
                        EventName = @EventName,
                        EventDateStart = @EventDateStart,
                        EventDateEnd = @EventDateEnd,
                        TimeStart = @TimeStart,
                        TimeEnd = @TimeEnd,
                        CustomerName = @CustomerName,
                        NumGuest = @NumGuest,
                        Address = @Address,
                        Contact = @Contact,
                        Preferences = @Preferences,
                        Status = @Status,
                        Gender = @Gender
                    WHERE EventID = @EventID";

              
                MySqlCommand command = new MySqlCommand(query, connection);

               
                command.Parameters.AddWithValue("@EventType", eventType);
                command.Parameters.AddWithValue("@EventName", eventName);
                command.Parameters.AddWithValue("@EventDateStart", eventDateStart);
                command.Parameters.AddWithValue("@EventDateEnd", eventDateEnd);
                command.Parameters.AddWithValue("@TimeStart", timeStart);
                command.Parameters.AddWithValue("@TimeEnd", timeEnd);
                command.Parameters.AddWithValue("@CustomerName", customerName);
                command.Parameters.AddWithValue("@NumGuest", numGuest);
                command.Parameters.AddWithValue("@Address", address);
                command.Parameters.AddWithValue("@Contact", contact);
                command.Parameters.AddWithValue("@Preferences", preferences);
                command.Parameters.AddWithValue("@Status", status);
                command.Parameters.AddWithValue("@Gender", gender);
                command.Parameters.AddWithValue("@EventID", eventId);

              
                command.ExecuteNonQuery();

                MessageBox.Show("Event updated successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                
                this.Close();
            }
            catch (MySqlException ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Update Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
               
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }
        }

        private void Update_Load(object sender, EventArgs e)
        {

        }

        private void btnCancel3_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
