﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using System.Windows.Forms;

namespace WindowsFormsApp6
{
    public partial class new_book : Form
    {
        
        private MySqlConnection connection;

        public new_book()
        {
            InitializeComponent();

           
            string connectionString = "server=localhost;database=eventmanagementdb;user=root;password='';";
            connection = new MySqlConnection(connectionString);
        }

        private void btnSave_Click_1(object sender, EventArgs e)
        {
           
            string eventType = txtEventType.Text;
            string eventName = txtEventName.Text;
            DateTime eventDateStart = dateTimePicker1.Value;
            DateTime eventDateEnd = dateTimePicker2.Value;
            TimeSpan timeStart = dateTimePicker3.Value.TimeOfDay;
            TimeSpan timeEnd = dateTimePicker4.Value.TimeOfDay;
            string customerName = txtCostumerName.Text;
            string contact = txtContact.Text;
            string address = txtAddress.Text;
            string preferences = richTxtBoxPreferenances.Text;
            string gender = radioMale.Checked ? "Male" : "Female";
            int numGuest;

            if (!int.TryParse(txtNumGuest.Text, out numGuest))
            {
               
                MessageBox.Show("Please enter a valid number for # of Guest.");
                return;
            }

            try
            {
                
                connection.Open();

               
                string insertEventQuery = @"
                    INSERT INTO Events 
                    (EventType, EventName, EventDateStart, EventDateEnd, TimeStart, TimeEnd, CustomerName, Contact, Address, Preferences, NumGuest, Gender)
                    VALUES 
                    (@EventType, @EventName, @EventDateStart, @EventDateEnd, @TimeStart, @TimeEnd, @CustomerName, @Contact, @Address, @Preferences, @NumGuest, @Gender)";

                using (MySqlCommand cmd = new MySqlCommand(insertEventQuery, connection))
                {
                    cmd.Parameters.AddWithValue("@EventType", eventType);
                    cmd.Parameters.AddWithValue("@EventName", eventName);
                    cmd.Parameters.AddWithValue("@EventDateStart", eventDateStart);
                    cmd.Parameters.AddWithValue("@EventDateEnd", eventDateEnd);
                    cmd.Parameters.AddWithValue("@TimeStart", timeStart);
                    cmd.Parameters.AddWithValue("@TimeEnd", timeEnd);
                    cmd.Parameters.AddWithValue("@CustomerName", customerName);
                    cmd.Parameters.AddWithValue("@Contact", contact);
                    cmd.Parameters.AddWithValue("@Address", address);
                    cmd.Parameters.AddWithValue("@Preferences", preferences);
                    cmd.Parameters.AddWithValue("@NumGuest", numGuest);
                    cmd.Parameters.AddWithValue("@Gender", gender);

                    cmd.ExecuteNonQuery();
                }

               
                MessageBox.Show("Booking saved successfully.");
            }
            catch (MySqlException ex)
            {
            
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                
                if (connection.State == ConnectionState.Open)
                {
                    connection.Close();
                }
            }
        }

        private void txtEventType_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnCancel2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void new_book_Load(object sender, EventArgs e)
        {

        }
    }
}
